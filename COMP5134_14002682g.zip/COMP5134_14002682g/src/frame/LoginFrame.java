package frame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import loginHandler.UserLoginHandler;

public class LoginFrame extends JFrame implements ActionListener {

	private static final long serialVersionUID = -2248657415132249L;
	
	private JLabel  titleLabel ;
	
	private JLabel  usernameLabel;
	
	private JLabel passwordLabel ;	
	
	private JTextField usernameText;
	
	private JPasswordField passwordText;
	
	private JButton submitButton;
	
	private JButton clearButton;
	
	private JLabel msgLabel;
	
	public LoginFrame(){
		super();
		init();
	}
	
	private void init(){
		
		JPanel panel=(JPanel)this.getContentPane();
		
		Font titleFont = new Font("Arial",Font.BOLD,24);
		
		Font textFont = new Font("Arial",Font.PLAIN,18);
		
		this.titleLabel = new JLabel("Welcome to Leave Application System - COMP5134");
		this.titleLabel.setFont(titleFont);
		this.titleLabel.setForeground(Color.RED);
		this.titleLabel.setSize(600, 50);
		this.titleLabel.setLocation(115, 30);
		
		this.usernameLabel = new JLabel("UserName:");
		this.usernameLabel.setFont(textFont);
		this.usernameLabel.setSize(100, 50);
		this.usernameLabel.setLocation(150, 150);
		
		this.passwordLabel = new JLabel("Password:");
		this.passwordLabel.setFont(textFont);
		this.passwordLabel.setSize(100, 50);
		this.passwordLabel.setLocation(150, 220);
		
		this.usernameText = new JTextField();
		this.usernameText.setFont(textFont);
		this.usernameText.setSize(300, 50);
		this.usernameText.setLocation(300, 150);
		
		this.passwordText = new JPasswordField();
		this.passwordText.setFont(textFont);
		this.passwordText.setSize(300, 50);
		this.passwordText.setLocation(300, 220);
		
		this.submitButton = new JButton("Submit");
		this.submitButton.setFont(textFont);
		this.submitButton.setSize(100, 50);
		this.submitButton.setLocation(200, 300);
		this.submitButton.addActionListener(this);
		
		this.clearButton = new JButton("Clear");
		this.clearButton.setFont(textFont);
		this.clearButton.setSize(100, 50);
		this.clearButton.setLocation(400, 300);
		this.clearButton.addActionListener(this);
		
		this.msgLabel = new JLabel();
		this.msgLabel.setFont(textFont);
		this.msgLabel.setSize(400, 50);
		this.msgLabel.setLocation(150, 400);
		
		panel.setLayout(null);
		panel.add(this.titleLabel);
		panel.add(this.usernameLabel);
		panel.add(this.passwordLabel);
		panel.add(this.usernameText);
		panel.add(this.passwordText);
		panel.add(this.submitButton);
		panel.add(this.clearButton);
		panel.add(this.msgLabel);
		
	    this.setSize(800,600);

		Toolkit kit = Toolkit.getDefaultToolkit();  
	    Dimension screenSize = kit.getScreenSize(); 
	    int screenWidth = screenSize.width/2;   
	    int screenHeight = screenSize.height/2;  
	    int height = this.getHeight();
	    int width = this.getWidth();
	    this.setLocation(screenWidth-width/2, screenHeight-height/2);
	    this.setVisible(true);
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getSource() == this.submitButton){
			login();
		}else if(arg0.getSource() == this.clearButton){
			clear();
		}
	}
	
	/**
	 * 
	 */
	@SuppressWarnings("deprecation")
	private void login(){
		this.msgLabel.setText("");
		boolean success = UserLoginHandler.login(this.usernameText.getText().trim(), this.passwordText.getText());
		if(success){
			this.setVisible(false);
			new PcenterFrame();
		}else{
			this.msgLabel.setText("username or password is incorrect!!!");
			this.msgLabel.setForeground(Color.RED);
		}		
	}
	
	/**
	 * 
	 */
	private void clear(){
		this.msgLabel.setText("");
		this.usernameText.setText("");
		this.passwordText.setText("");
	}
	
	public static void main(String[] args){
		new LoginFrame();		
	}
	
}
