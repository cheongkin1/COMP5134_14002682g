package frame;

import java.awt.Color;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import data.DataCenter;
import leaveApplication.ApplicationStatus;
import leaveApplication.LeaveApplication;
import loginHandler.UserLoginHandler;
import utils.DateUtil;
import utils.StringUtil;

public class AddApplicationFrame extends BaseWorkFrame{

	private static final long serialVersionUID = -1740443273926945787L;
	
	private JLabel reasonLabel;
	private JLabel fromDateLabel;
	private JLabel toDateLabel;
	private JTextField reasonValue;
	private JTextField fromDateValue;
	private JTextField toDateValue;
	private JButton submitButton;
	private JButton clearButton;
	private JLabel msgLabel;
	
	@Override
	public void init() {
		
		reasonLabel = new JLabel("reason:");
		reasonLabel.setFont(textFont);
		reasonLabel.setSize(150, 30);
		reasonLabel.setLocation(100, 60);
		
		fromDateLabel = new JLabel("fromDate:");
		fromDateLabel.setFont(textFont);
		fromDateLabel.setSize(150, 30);
		fromDateLabel.setLocation(100, 100);
		
		toDateLabel = new JLabel("toDate:");
		toDateLabel.setFont(textFont);
		toDateLabel.setSize(150, 30);
		toDateLabel.setLocation(100, 140);
		
		reasonValue = new JTextField();
		reasonValue.setFont(textFont);
		reasonValue.setSize(200, 30);
		reasonValue.setLocation(270, 60);
		
		fromDateValue = new JTextField();
		fromDateValue.setFont(textFont);
		fromDateValue.setSize(200, 30);
		fromDateValue.setLocation(270, 100);
		
		toDateValue = new JTextField();
		toDateValue.setFont(textFont);
		toDateValue.setSize(200, 30);
		toDateValue.setLocation(270, 140);
		
		submitButton = new JButton("Submit");
		submitButton.setFont(textFont);
		submitButton.setSize(200, 30);
		submitButton.setLocation(100, 220);
		
		clearButton = new JButton("Clear");
		clearButton.setFont(textFont);
		clearButton.setSize(200, 30);
		clearButton.setLocation(270, 220);
		
		msgLabel =  new JLabel();
		msgLabel.setFont(textFont);
		msgLabel.setSize(400, 30);
		msgLabel.setLocation(100, 270);
		msgLabel.setForeground(Color.RED);
		
		this.panel.add(reasonLabel);
		this.panel.add(fromDateLabel);
		this.panel.add(toDateLabel);
		this.panel.add(reasonValue);
		this.panel.add(fromDateValue);
		this.panel.add(toDateValue);
		this.panel.add(submitButton);
		this.panel.add(clearButton);
		this.panel.add(msgLabel);
		
		submitButton.addActionListener(this);
		clearButton.addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getSource() == this.submitButton){
			addApplication();
			return;
		}else if(arg0.getSource() == this.clearButton){
			clear();
			return;
		}
		CommanAction.actionPerformed(this, this.newApplicationMenuItem, (JMenuItem)arg0.getSource());
	}
	
	
	private boolean addApplication(){
		msgLabel.setText("");
		if(StringUtil.isBlank(reasonValue.getText())){
			msgLabel.setText("reason can not be null!!!");
			return false;
		}
		
		if(StringUtil.isBlank(fromDateValue.getText())){
			msgLabel.setText("fromDate can not be null!!!");
			return false;
		}
		
		if(StringUtil.isBlank(toDateValue.getText())){
			msgLabel.setText("toDate can not be null!!!");
			return false;
		}
		LeaveApplication application = new LeaveApplication();
		application.setReason(reasonValue.getText().trim());
		application.setFromDate(fromDateValue.getText().trim());
		application.setToDate(toDateValue.getText().trim());
		application.setCreateTime(DateUtil.getDateStr());
		application.setProposerId(UserLoginHandler.getLoginStaff().getId());
		application.setStatus(ApplicationStatus.PROCESSING);
		
		boolean success = DataCenter.addLeaveApplication(application);
		if(success){
			JOptionPane.showMessageDialog(null,"Suceess to submit Leave Application");
		}else{
			JOptionPane.showMessageDialog(null,"Failed to submit Leave Application");
		}
		return success;
	}
	
	private void clear(){
		reasonValue.setText("");
		fromDateValue.setText("");
		toDateValue.setText("");
		msgLabel.setText("");
	}
	
}
