package frame;

import java.awt.Color;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import data.DataCenter;
import leaveApplication.Role;
import leaveApplication.Staff;
import utils.StringUtil;

public class AddStaffFrame extends BaseWorkFrame{

	private static final long serialVersionUID = -1740443273926945787L;
	
	private JLabel unameLabel;
	private JLabel pwdLabel;
	private JLabel realnameLabel;
	private JLabel supervisiorLabel;
	private JTextField unameValue;
	private JTextField pwdValue;
	private JTextField realnameValue;
	private JTextField supervisiorValue;
	private JButton submitButton;
	private JButton clearButton;
	private JLabel msgLabel;
	
	@Override
	public void init() {
		
		unameLabel = new JLabel("UserName:");
		unameLabel.setFont(textFont);
		unameLabel.setSize(150, 30);
		unameLabel.setLocation(100, 60);
		
		pwdLabel = new JLabel("Password:");
		pwdLabel.setFont(textFont);
		pwdLabel.setSize(150, 30);
		pwdLabel.setLocation(100, 100);
		
		realnameLabel = new JLabel("RealName:");
		realnameLabel.setFont(textFont);
		realnameLabel.setSize(150, 30);
		realnameLabel.setLocation(100, 140);
		
		supervisiorLabel = new JLabel("Supervisior:");
		supervisiorLabel.setFont(textFont);
		supervisiorLabel.setSize(150, 30);
		supervisiorLabel.setLocation(100, 180);
		
		unameValue = new JTextField();
		unameValue.setFont(textFont);
		unameValue.setSize(200, 30);
		unameValue.setLocation(270, 60);
		
		pwdValue = new JTextField();
		pwdValue.setFont(textFont);
		pwdValue.setSize(200, 30);
		pwdValue.setLocation(270, 100);
		
		realnameValue = new JTextField();
		realnameValue.setFont(textFont);
		realnameValue.setSize(200, 30);
		realnameValue.setLocation(270, 140);
		
		supervisiorValue = new JTextField();
		supervisiorValue.setFont(textFont);
		supervisiorValue.setSize(200, 30);
		supervisiorValue.setLocation(270, 180);
		
		submitButton = new JButton("Submit");
		submitButton.setFont(textFont);
		submitButton.setSize(200, 30);
		submitButton.setLocation(100, 220);
		
		clearButton = new JButton("Clear");
		clearButton.setFont(textFont);
		clearButton.setSize(200, 30);
		clearButton.setLocation(270, 220);
		
		msgLabel =  new JLabel();
		msgLabel.setFont(textFont);
		msgLabel.setSize(400, 30);
		msgLabel.setLocation(100, 270);
		msgLabel.setForeground(Color.RED);
		
		this.panel.add(unameLabel);
		this.panel.add(pwdLabel);
		this.panel.add(realnameLabel);
		this.panel.add(supervisiorLabel);
		this.panel.add(unameValue);
		this.panel.add(pwdValue);
		this.panel.add(realnameValue);
		this.panel.add(supervisiorValue);
		this.panel.add(submitButton);
		this.panel.add(clearButton);
		this.panel.add(msgLabel);
		
		submitButton.addActionListener(this);
		clearButton.addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getSource() == this.submitButton){
			addStaff();
			return;
		}else if(arg0.getSource() == this.clearButton){
			clear();
			return;
		}
		CommanAction.actionPerformed(this, this.newStaffMenuItem, (JMenuItem)arg0.getSource());
	}
	
	private boolean addStaff(){
		msgLabel.setText("");
		if(StringUtil.isBlank(unameValue.getText())){
			msgLabel.setText("user name can not be null!!!");
			return false;
		}
		
		if(StringUtil.isBlank(pwdValue.getText())){
			msgLabel.setText("passord can not be null!!!");
			return false;
		}
		
		if(StringUtil.isBlank(realnameValue.getText())){
			msgLabel.setText("real name can not be null!!!");
			return false;
		}
		
		if(StringUtil.isBlank(supervisiorValue.getText())){
			msgLabel.setText("supervisior can not be null!!!");
			return false;
		}
		Staff supervisior = DataCenter.getStaffByUsername(supervisiorValue.getText().trim());
		if(null == supervisior){
			msgLabel.setText("supervisior does not exist!!!");
			return false;
		}
		
		Staff staff = new Staff();
		staff.setUsername(unameValue.getText().trim());
		staff.setRole(Role.STAFF);
		staff.setRealname(realnameValue.getText().trim());
		staff.setPassword(pwdValue.getText().trim());
		staff.setSupervisiorId(supervisior.getId());

		
		boolean success = DataCenter.addStaff(staff);
		if(success){
			JOptionPane.showMessageDialog(null,"Suceess add staff");
		}else{
			JOptionPane.showMessageDialog(null,"Failed add staff");
		}
		return success;
	}
	
	private void clear(){
		unameValue.setText("");
		pwdValue.setText("");
		realnameValue.setText("");
		supervisiorValue.setText("");
		msgLabel.setText("");
	}
	
}
