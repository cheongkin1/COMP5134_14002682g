package leaveApplication;


public enum Role {
	STAFF,
	DIRECTOR
}
