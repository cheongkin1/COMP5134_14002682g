package leaveApplication;

public enum IdType {
	ST,
	LA,
	AP
}
