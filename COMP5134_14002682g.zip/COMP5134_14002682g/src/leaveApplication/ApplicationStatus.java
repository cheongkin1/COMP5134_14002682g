package leaveApplication;

public enum ApplicationStatus {
	SUCCESS,
	FAILED,
	PROCESSING
}
