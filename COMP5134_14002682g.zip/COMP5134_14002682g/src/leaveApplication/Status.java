package leaveApplication;

public enum Status {
	ENDORSE,
	DECLINE,
	UNPROCESSED
}
