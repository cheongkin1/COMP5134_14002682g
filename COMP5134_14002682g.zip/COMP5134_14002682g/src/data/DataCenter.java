package data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import leaveApplication.ApplicationStatus;
import leaveApplication.ApprovalProcess;
import leaveApplication.IdType;
import leaveApplication.LeaveApplication;
import leaveApplication.Role;
import leaveApplication.Staff;
import leaveApplication.Status;
import utils.IdGenerator;
import utils.StringUtil;

public final class DataCenter {

	private final static Map<String,Staff> idStaffMap = new HashMap<String,Staff>();

	private final static Map<String,Staff> usernameStaffMap = new HashMap<String,Staff>();
	
	/**
	 * Staff and supervisor relation map
	 */
	private final static Map<String,List<Staff>> supervisorStaffMap =  new HashMap<String,List<Staff>>();
	

	private final static Map<String,LeaveApplication> idApplicationMap = new HashMap<String,LeaveApplication>();
	
	
	private final static Map<String,List<LeaveApplication>> proposerIdApplicationMap = new HashMap<String,List<LeaveApplication>>();
	

	private final static Map<String,ApprovalProcess> idProcessMap = new HashMap<String,ApprovalProcess>();

	private final static Map<String,List<ApprovalProcess>> applicationIdProcessMap = new HashMap<String,List<ApprovalProcess>>();


	private final static Map<String,List<ApprovalProcess>> supervisorIdProcessMap = new HashMap<String,List<ApprovalProcess>>();

	/**
	 * 
	 * @param id
	 * @return
	 */
	public static Staff getStaffById(String id){
		return idStaffMap.get(id);
	}
	
	/**
	 * 
	 * @param username
	 * @return
	 */
	public static Staff getStaffByUsername(String username){
		return usernameStaffMap.get(username);
	}
	
	/**
	 * 
	 * @param supervisorId
	 * @return
	 */
	public static List<Staff> getStaffBySupervisorId(String supervisorId){
		return supervisorStaffMap.get(supervisorId);
	}
	
	/**
	 * 
	 * @param id
	 * @return
	 */
	public static LeaveApplication getApplicationById(String id){
		return idApplicationMap.get(id);
	}
	
	/**
	 * 
	 * @param proposerId
	 * @return
	 */
	public static List<LeaveApplication> getApplicationByProposerId(String proposerId){
		return proposerIdApplicationMap.get(proposerId);
	}
	/**
	 * 
	 * @param id
	 * @return
	 */
	public static ApprovalProcess getApprovalProcessById(String id){
		return idProcessMap.get(id);
	}
	
	/**
	 * 
	 * @param applicationId
	 * @return
	 */
	public static List<ApprovalProcess> getApprovalProcessByApplicationId(String applicationId){
		return applicationIdProcessMap.get(applicationId);
	}
	
	/**
	 * 
	 * @param supervisorId
	 * @return
	 */
	public static List<ApprovalProcess> getApprovalProcessBySupervisorId(String supervisorId){
		return supervisorIdProcessMap.get(supervisorId);
	}
	
	
	/**
	 * 
	 */
	static{
		Staff staff = null;
		
		String directorId = null;
		String staff1Id = null;
		
		staff = new Staff();
		staff.setUsername("director");
		staff.setPassword("director");
		staff.setRealname("director");
		staff.setRole(Role.DIRECTOR);
		addStaff(staff);
		directorId = staff.getId();
		

		staff = new Staff();
		staff.setUsername("staff1");
		staff.setPassword("staff1");
		staff.setRealname("staff1");
		staff.setRole(Role.STAFF);
		staff.setSupervisiorId(directorId);
		addStaff(staff);
		staff1Id = staff.getId();
		
		staff = new Staff();
		staff.setUsername("staff2");
		staff.setPassword("staff2");
		staff.setRealname("staff2");
		staff.setRole(Role.STAFF);
		staff.setSupervisiorId(directorId);
		addStaff(staff);
		
		staff = new Staff();
		staff.setUsername("staff3");
		staff.setPassword("staff3");
		staff.setRealname("staff3");
		staff.setRole(Role.STAFF);
		staff.setSupervisiorId(directorId);
		addStaff(staff);
		
		staff = new Staff();
		staff.setUsername("test1");
		staff.setPassword("test1");
		staff.setRealname("test1");
		staff.setRole(Role.STAFF);
		staff.setSupervisiorId(staff1Id);
		addStaff(staff);

	}
	
	public static List<Staff> getAllStaff(){
		List<Staff> list =  new ArrayList<Staff>(idStaffMap.values());
		List<Staff> normalStaffList = new  ArrayList<Staff>();
		for(Staff staff:list){
			if(!staff.isDeleted()){
				normalStaffList.add(staff);
			}
		}
		return normalStaffList;
	} 
	
	/**
	 * 
	 * @param staff
	 * @return
	 */
	public static boolean addStaff(Staff staff){
		if(null == staff ||StringUtil.isBlank(staff.getUsername()) || StringUtil.isBlank(staff.getPassword())){
			return false;
		}
		
		if(null == staff.getSupervisiorId() && staff.getRole() != Role.DIRECTOR){
			return false;
		}
		
		staff.setId(IdGenerator.getGenerateId(IdType.ST.name()));
		if(idStaffMap.containsKey(staff.getId()) || usernameStaffMap.containsKey(staff.getUsername())){
			return false;
		}		
		
		/**
		 * 
		 */
		boolean hasLoop = false;
		Staff supervisor = getStaffById(staff.getSupervisiorId());
		Set<String> supervisorIds = new HashSet<String>();
		
		while(null != supervisor && null != supervisor.getSupervisiorId()){
			if(supervisorIds.contains(supervisor.getId())){
				hasLoop = true;
				break;
			}
			supervisorIds.add(supervisor.getId());
			supervisor = getStaffById(supervisor.getSupervisiorId());
		}
		
		if(hasLoop){
			return false;
		}
		
		
		idStaffMap.put(staff.getId(), staff);
		usernameStaffMap.put(staff.getUsername(), staff);
		
		List<Staff> staffs = supervisorStaffMap.get(staff.getSupervisiorId());
		if(null == staffs){
			staffs = new ArrayList<Staff>();
			supervisorStaffMap.put(staff.getSupervisiorId(), staffs);
		}
		staffs.add(staff);
		
		return true;
	}
	
	/**
	 * 
	 * @param id
	 * @return
	 */
	public static boolean deleteStaff(String id){
		if(StringUtil.isBlank(id)){
			return false;
		}
		
		Staff staff = idStaffMap.get(id);
		if(null == staff || staff.isDeleted()){
			return false;
		}	
		
		List<Staff> subordinates = supervisorStaffMap.get(id);
		

		if(null != subordinates){
			for(Staff subordinate:subordinates){
				subordinate.setSupervisiorId(staff.getSupervisiorId());
			}
		}
		

		List<ApprovalProcess> processes = supervisorIdProcessMap.get(staff.getId());
		List<ApprovalProcess> supervisiorProcesses = supervisorIdProcessMap.get(staff.getSupervisiorId());
		if(null == supervisiorProcesses ){
			supervisiorProcesses = new ArrayList<ApprovalProcess>();
			supervisorIdProcessMap.put(staff.getSupervisiorId(), supervisiorProcesses);
		}
		
		if(null != processes && !processes.isEmpty()){
			for(ApprovalProcess process: processes){
				if(process.getStatus() == Status.UNPROCESSED){
					process.setSupervisorId(staff.getSupervisiorId());
					supervisiorProcesses.add(process);
				}				
			}
		}
		
		
		staff.setDeleted(true);
		return true;
	}
	
	/**
	 * 
	 * @param application
	 * @return
	 */
	public static boolean addLeaveApplication(LeaveApplication application){
		if(null == application){
			return false;
		}
		
		application.setId(IdGenerator.getGenerateId(IdType.LA.name()));
		idApplicationMap.put(application.getId(), application);
	
		List<LeaveApplication> proposerApplications =  proposerIdApplicationMap.get(application.getProposerId());
		if(null == proposerApplications){
			proposerApplications = new ArrayList<LeaveApplication>();
			proposerIdApplicationMap.put(application.getProposerId(), proposerApplications);
		}
		
		proposerApplications.add(application);
		
		ApprovalProcess process = new ApprovalProcess();
		process.setId(IdGenerator.getGenerateId(IdType.AP.name()));
		process.setApplicationId(application.getId());
		process.setSupervisorId(idStaffMap.get(application.getProposerId()).getSupervisiorId());
		
		addApprovalProcess(process);
		
		return true;
	}
	
	/**
	 * 
	 * @param process
	 * @return
	 */
	public static boolean processApproval(ApprovalProcess process){
		Staff staff = idStaffMap.get(process.getSupervisorId());
		LeaveApplication application = idApplicationMap.get(process.getApplicationId());
		supervisorIdProcessMap.remove(process.getSupervisorId());
		if(process.getStatus() == Status.ENDORSE && staff.getRole() == Role.DIRECTOR){
			application.setStatus(ApplicationStatus.SUCCESS);
		}else if(process.getStatus() == Status.DECLINE ){
			application.setStatus(ApplicationStatus.FAILED);
		}else{
			ApprovalProcess nextProcess = new ApprovalProcess();
			nextProcess.setId(IdGenerator.getGenerateId(IdType.AP.name()));
			nextProcess.setApplicationId(process.getApplicationId());
			nextProcess.setSupervisorId(idStaffMap.get(process.getSupervisorId()).getSupervisiorId());
			
			addApprovalProcess(nextProcess);
		}		
		
		return true;
	}
	/**
	 * 
	 * @param process
	 * @return
	 */
	public static boolean addApprovalProcess(ApprovalProcess process){
		if(StringUtil.isBlank(process.getId())||StringUtil.isBlank(process.getApplicationId()) || StringUtil.isBlank(process.getSupervisorId())){
			return false;
		}

		idProcessMap.put(process.getId(), process);
				
		List<ApprovalProcess> processes = new ArrayList<ApprovalProcess>();
		processes.add(process);
		applicationIdProcessMap.put(process.getApplicationId(), processes);
				
		List<ApprovalProcess> supervisorProcesses = new ArrayList<ApprovalProcess>();
		supervisorProcesses.add(process);
		supervisorIdProcessMap.put(process.getSupervisorId(), processes);
		return true;
	}
}
